# PCBWay Fab Notes — MT6835_hub_rev_a

## Upload package
- `PCBWAY_FAB_2026-02-26/MT6835_hub_rev_a_PCBWAY_FAB_2026-02-26.zip`

## BOM upload
- `BOM_PCBWAY.csv`

## Technical verification
- ERC: 0
- DRC: 0
- Unconnected: 0
- Schematic parity: 0

## Connector list (BOM-verified)
1. `J0`: `Amphenol RJHSE5380`
   - Footprint: `Connector_RJ:RJ45_Amphenol_RJHSE5380`
   - Mounting: THT
2. `J1-J3`: `Molex 53398-0671`
   - Footprint: `Connector_Molex:Molex_PicoBlade_53398-0671_1x06-1MP_P1.25mm_Vertical`
   - Mounting: SMD

## Mating cable side (for reference, not PCB assembly)
- Housing: `Molex 51021-0600`
- Crimp terminals: `Molex 50079-8100`
