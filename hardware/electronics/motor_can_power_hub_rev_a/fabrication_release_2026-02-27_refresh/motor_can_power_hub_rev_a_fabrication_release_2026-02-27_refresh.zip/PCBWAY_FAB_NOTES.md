# PCBWay Fab Notes — motor_can_power_hub_rev_a

## Upload package
- `PCBWAY_FAB_2026-02-27_refresh/motor_can_power_hub_rev_a_PCBWAY_FAB_2026-02-27_refresh.zip`

## Package contents
- `gerbers/` (all Gerber + Excellon + drill map)
- `BOM_PCBWAY.csv`
- `ORDER_NOTES.txt`

## Drill constraint check
- Min drill in current generated file: `0.60 mm`
- PCBWay requirement: `>= 0.20 mm`
- Status: **PASS**

## BOM summary (THT only)
1. `J_PWR_IN1`: AMASS `XT60PW-M` (horizontal, THT)
2. `J_CAN_IN1`: Phoenix Contact `1725656` (3-pin, 2.54 mm, THT)
3. `J_MOTOR1-J_MOTOR5`: JST `B6B-ZR(LF)(SN)` (6-pin ZH 1.50 mm, THT)

## Upload behavior on PCBWay
- For **PCB fabrication only**: upload package ZIP only.
- For **PCBA (THT assembly)**:
  - BOM: `BOM_PCBWAY.csv`
  - Centroid/CPL: optional for this design (THT only)
  - Other files: `ORDER_NOTES.txt`
